###16 Hive

Hadoop生态系统中的数据仓库工具，允许用户使用SQL对HDFS上的数据进行操作，常见的操作如查询和分析。

原生的Hive是将用户的SQL语句翻译成MapReduce任务，在集群上执行。

Hive使用Facebook开发之后，共享给Apache，主要是让不懂Java编程的使用者可以基于SQL进行大数据分析。

Hive提供了一种类SQL的操作语言HiveQL

###16.1 安装Hive

- 获取安装文件
- 解压缩
- 配置环境变量
- 配置Hive的配置文件
- 启动Hive
启动Hive的前提是已经启动了Hadoop

###16.2 使用Hive

用户基于HiveQL对Hive进行操作，进而操作HDFS上的数据，HiveQL与SQL非常类似，因此操作Hive就像在操作关系型数据库。

- 建库

在hive中如果没有使用`use`命令选择库，所有的操作是默认基于`default`库的

- 建表

- 使用HiveQL操作表

从ftp上的车次数据文件夹下载20190601.zip文件并解压缩，可以得到一个`20190601.csv`文件

.csv格式的数据是标准的结构化数据，每行文本是一条数据，一条数据的多个字段使用逗号进行分割。文件的最上方一行一般是表头。

该文件最好不要使用excel等工具进行打开，因为这些软件会自动修改文件的内容以适合操作。

需求：将20190601.csv的数据导入到hive中，基于hiveQL进行分析

将文件从windows上传linux 

	cd /opt
	rz -y
	对话框中选中20190601.csv，选择上传

将文件从Linux上传hdfs

	hdfs dfs -put /opt/20190601.csv /
	查询
	hdfs dfs -ls /

在Hive中建库和建表

	-- 创建库
	create database nybikedb;
	
	-- 使用库
	use nybikedb;
	
	-- 创建表
	create table tb_trip_1(
	tripduration int,
	starttime string,
	stoptime string,
	start_station_id int,
	start_station_name string,
	start_station_latitude double,
	start_station_longitude double,
	end_station_id int,
	end_station_name string,
	end_station_latitude double,
	end_station_longitude double,
	bikeid int,
	usertype string,
	birth_year int,
	gender int
	)ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';
	-- hive关联的原始数据字段的分隔符使用逗号 
	
	-- 导入hdfs上的数据
	load data inpath 'hdfs://master:8020/20190601-3.csv' 
	overwrite into table tb_trip_1;

	-- 检查导入的数据条数 (76419)
	select count(*) from tb_trip_1;

	-- 检查一条数据的字段是否正确 
	select * from tb_trip_1 limit 1;

	-- 统计数据中所有男性骑行者的数量 (45072)
	select count(*) from tb_trip_1 where gender=1;

当我们将文件数据导入到Hive中后，原来在hdfs本目录下的`20190601-3.csv`会被自动放入以下路径`/hive/warehouse/nybikedb.db/tb_trip_1/`，相当于该文件交给hive来管理

###17 使用Hive进行数据分析

需求：
对20190601一天的数据进行分析
- 骑行者的男女比例
- 骑行者各年龄段(阶段的划分需要有依据)的数量
- 不同用户类型的比例/数量
- 不同用车时长(5分钟、2小时)的数量
- 男女的骑车时长(平均、总)
- 不同时间段统计(开始骑车的数量，结束骑车的数量，在骑行中的数量)
- 热点起始站点/结束站点
- 热点起始区域(经纬度切成多个区域/行政区域)
- 各区域在0点的可用车数量和可用桩数量，对比24小时之后各区域的可用车数量和可用桩数量(trip数据没有该字段，用station_status数据)

示例1：6月1日骑行者的男女比例

大数据平台：

- hive上建表，来保存分析结果

- hive上分析数据，将结果保存到目标表中

- 进行必要的配置，保证JavaWeb程序可以顺利访问Hive

	首先需要配置hive的配置文件 hive-site.xml

		cd /opt/hive-2.3.5/conf
		vim hive-site.xml

		在<configuration></configuration>标签中添加以下内容

		<property>
			<name>hive.server2.thrift.port</name>
			<value>10000</value>
		</property>
		<property>
			<name>hive.server2.thrift.client.user</name>
			<value>root</value>
		</property>
		<property>
	<name>hive.server2.thrift.client.password</name>
			<value>root</value>
		</property>

	然后配置Hadoop的配置文件 core-site.xml

		cd /opt/hadoop-2.6.5/etc/hadoop
		vim core-site.xml

	在<configuration></configuration>标签中添加以下内容

		<property>
			<name>hadoop.proxyuser.root.hosts</name>
			<value>*</value>
		</property>
		<property>
			<name>hadoop.proxyuser.root.groups</name>
			<value>*</value>
		</property>

	配置成功后，注意要关闭并重新启动hadoop

JavaWeb项目：

- 基于JDBC访问Hive，从目标表中查询分析结果（XXXDO）

- 将XXXDO(以一条数据为单位，理论上同时包含X轴的值和Y轴的值)转变成XXXVO(X轴数据的集合+Y轴数据的集合)

- 将XXXVO转成JSON格式，发送给浏览器

前端界面：

- 发送AJAX请求分析的结果

- 初始化Echarts图表，添加数据

- 在页面上显示数据的图表

答辩：每个组要提供3个数据分析用例，多了有加分，最多加2个