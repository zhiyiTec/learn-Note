package cn.tedu.nybike.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import cn.tedu.nybike.pojo.StationStatusDO;
import cn.tedu.nybike.util.DBUtils;

public class StationDAO {
	
	// ������
	public void batchSaveStatus(
			List<StationStatusDO> list){
		String sql="insert into tb_status "
				+ "values(null,?,?,?,?,?)";
		
		// ��ȡ����
		// ��ȡSQLִ����
		try(Connection conn=DBUtils.getConn();
				PreparedStatement ps=conn.prepareStatement(sql)){
			// ����list����
			for(StationStatusDO ssDO:list){
				// �󶨲���
				ps.setInt(1, ssDO.getStation_id());
				ps.setInt(2, ssDO.getNum_bikes_available());
				ps.setInt(3, ssDO.getNum_bikes_disabled());
				ps.setInt(4, ssDO.getNum_docks_available());
				ps.setInt(5, ssDO.getNum_docks_disabled());
				// ��SQL���ӵ�����
				ps.addBatch();
			}
			// �ύ��
			ps.executeBatch();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
