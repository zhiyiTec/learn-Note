package cn.tedu.nybike.pojo;

import java.util.List;

public class GenderCountVO {
	
	private List<GCItem> data;

	public GenderCountVO() {
	}

	public List<GCItem> getData() {
		return data;
	}

	public void setData(List<GCItem> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "GenderCountVO [data=" + data + "]";
	}

}
