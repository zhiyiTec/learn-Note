package cn.tedu.nybike.pojo;

import java.sql.Date;

public class GenderCountDO {
	
	private Date startDate;
	private Integer gender;
	private Integer num;
	
	public GenderCountDO() {
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Integer getGender() {
		return gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	@Override
	public String toString() {
		return "GenderCountDO [startDate=" + startDate + ", gender=" + gender + ", num=" + num + "]";
	}
	
}
