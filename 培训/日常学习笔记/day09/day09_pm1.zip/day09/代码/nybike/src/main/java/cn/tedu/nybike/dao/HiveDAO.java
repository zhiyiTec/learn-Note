package cn.tedu.nybike.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.tedu.nybike.pojo.GenderCountDO;
import cn.tedu.nybike.util.HiveDBUtil;

public class HiveDAO {
	// ����Ļ���ԭ��JDBC���������ֻ����DAO��

	/**
	 * ��ѯ����GenderCount�ķ���
	 * @return ��װ��GenderCount�ļ��� �� �ռ���
	 */
	public List<GenderCountDO> listGenderCount(){
		List<GenderCountDO> list=new ArrayList<>();
		String sql="select * from tb_gender_count";
		try(Connection conn=HiveDBUtil.getHiveConn();
				PreparedStatement ps=conn.prepareStatement(sql)){
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				GenderCountDO gc=new GenderCountDO();
				gc.setStartDate(rs.getDate("start_date"));
				gc.setGender(rs.getInt("gender"));
				gc.setNum(rs.getInt("num"));
				
				list.add(gc);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}



